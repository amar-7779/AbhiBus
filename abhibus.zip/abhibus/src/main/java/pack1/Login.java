package pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Login {
	public static void main(String[] args) throws Exception {

    	ChromeOptions opt = new ChromeOptions();
		opt.addArguments("--incognito");
		WebDriver driver = new ChromeDriver(opt);
       

        driver.get(" https://www.abhibus.com/?utm_source=google&utm_medium=cpc&utm_campaign=Abhibus_Brand&utm_term=abhibus&utm_content=Brand&gad_source=1&gad_campaignid=14578306550&gbraid=0AAAAABNk5GtPdnuhus5jMtmvz0dB39eLE&gclid=CjwKCAjw_eLVBhBEEiwAeaYZfIQ819oBmBliULlM_7aRTwUlrbnHwy-pWMPq0HRvxH1GxeFk-A2vARoCE2MQAvD_BwE ");

        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[normalize-space()='Login/SignUp']")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[contains(@inputmode,'tel')]")).sendKeys("9010037998");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
        Thread.sleep(25000);
        driver.findElement(By.xpath("//a[@id='user-link']//*[name()='svg']//*[name()='path' and contains(@fill,'currentCol')]")).click();
        Thread.sleep(5000);
        
        if(driver.findElement(By.xpath("//*[normalize-space()='My Bookings']")).isDisplayed())
        {
            System.out.println("Successfully login application");
            Thread.sleep(5000);
        }
        else
        {
            System.out.println("Login Failed");
        }

        driver.quit();
    }
}

